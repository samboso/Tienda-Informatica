<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InsertarController extends Controller
{
    public function FunctionName(Request $request)
    {
        return view('insertar');
    }
}
