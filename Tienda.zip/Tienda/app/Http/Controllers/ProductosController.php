<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Productos;
//use App\Http\Controllers\Redirect;
//use Redirect;

//use App\Http\Controllers\ProductosController;

class ProductosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $productos = Productos::all();
        return view('producto.productoslista', compact('productos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('producto.productoslista');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'id' => 'required',
            'nombre' => 'required',
            'precio' => 'required',
            'observaciones' => 'required',
            'almacen' => 'required',
            'categoria' => 'required',
        ]);

        $productos = new Productos;

        $productos->id = $request->input('id');
        $productos->nombre = $request->input('nombre');
        $productos->precio = $request->input('precio');
        $productos->observaciones = $request->input('observaciones');
        $productos->almacen = $request->input('almacen');
        $productos->categoria = $request->input('categoria');

        $productos->save();

        return redirect('producto')->with('success','Datos añadidos');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $productos = Productos::find($id);
        return view('producto.productoseditar', compact('productos', 'id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $productos = Productos::find($id);

        $productos->nombre = request('nombre');
        $productos->precio = request('precio');
        $productos->observaciones = request('observaciones');
        $productos->almacen = request('almacen');
        $productos->categoria = request('categoria');

        $productos->save();

        return redirect('producto')->with('success','Datos actualizados');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $productos = Productos::find($id);
        $productos->delete();

        return redirect('producto')->with('success','Datos eliminados');
    }
}
