<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Editar producto</title>
</head>
<body>

<?php if(\Session::has('success')): ?>
<div class="alert alert-danger">
    <h4><?php echo e(\Session::get('success')); ?></h4>
</div>
<?php endif; ?>

    <form method="POST" action="<?php echo e(action('ProductosController@update', $id)); ?>" name="productosForm">

    <?php echo e(csrf_field()); ?>


        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Editar productos informática</h4>
                        </div>
                        <div class="card-body">
                        <a href="/insertar" class="btn btn-primary btn-sm">Insertar</a>
                        <a href="/producto" class="btn btn-primary btn-sm">Lista</a>
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <td>
                                            <label class="form-label">ID</label>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" id="id" name="id" value="<?php echo e($productos->id); ?>" disabled>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Nombre</label>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($productos->nombre); ?>"  maxlength="50" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Precio</label>
                                        </td>
                                        <td>
                                            <input type="number" class="form-control" id="precio" name="precio" value="<?php echo e($productos->precio); ?>" min="0" step="any" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Observaciones</label>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" id="observaciones" name="observaciones" value="<?php echo e($productos->observaciones); ?>" maxlength="100" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Almacén</label>
                                        </td>
                                        <td>
                                        <input type="number" class="form-control" id="almacen" name="almacen" value="<?php echo e($productos->almacen); ?>" min="1" max="3" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="form-label">Categoría</label>
                                        </td>
                                        <td>
                                            <input type="number" class="form-control" id="categoria" name="categoria" value="<?php echo e($productos->categoria); ?>" min="1" max="7" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type="checkbox" class="form-check-input" id="checkdata" required>
                                            <label class="form-check-label" for="exampleCheck1">Confirmar datos</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php echo e(method_field('PUT')); ?>

                                            <button type="submit" class="btn btn-primary" style="widht:50%">Editar datos</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script src="\cusotm.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\Tienda\resources\views/producto/productoseditar.blade.php ENDPATH**/ ?>