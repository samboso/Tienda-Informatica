$("form[name='productosForm']").submit(function (event) {
    var validarNombre = document.forms["productosForm"]["nombre"].value;
     if (validarNombre.length == 1 || validarNombre.length == 2 ) {
        alert("¡Por favor, introduzca un nombre más largo!");
        event.preventDefault();
    } if (validarNombre.length >= 3) {
        event.submit();
    }
});