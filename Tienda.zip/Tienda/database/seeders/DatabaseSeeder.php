<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
//use Database\Seeders\DB;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        
        DB::table('almacenes')->insert([
            'nombre' => 'Las Palmas',
        ]);
        DB::table('almacenes')->insert([
            'nombre' => 'Vecindario',
        ]);
        DB::table('almacenes')->insert([
            'nombre' => 'Telde',
        ]);
        

        
        DB::table('categorias')->insert([
            'nombre' => 'Ordenador de sobremesa',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Ordenador portátil',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Ratón',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Alfombrilla',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Altavoces',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Pantalla',
        ]);
        DB::table('categorias')->insert([
            'nombre' => 'Silla',
        ]);
        

        DB::table('productos')->insert([
            'nombre' => 'PC gaming - Acer Nitro DG.E2DEB.002',
            'precio' => 999,
            'observaciones' => ' Intel® Core™ i5-11400F, 16 GB RAM, 1024 GB SSD, GeForce® GTX 1650, W10',
            'almacen' => 1,
            'categoria' => 1,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Apple iMac MGPC3Y/A, 24" Retina 4K',
            'precio' => 1519,
            'observaciones' => 'Apple M1, 256 GB SSD, MacOS, Plata',
            'almacen' => 3,
            'categoria' => 1,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'MacBook Air Apple MGN93Y/A, 13.3" Retina',
            'precio' => 929,
            'observaciones' => 'Apple Silicon M1, 8 GB, 256 GB SSD, MacOS, Plata',
            'almacen' => 2,
            'categoria' => 2,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Portátil - HP 14s-dq0012ns, 14" HD',
            'precio' => 329,
            'observaciones' => 'Intel® Celeron® N4020, 4 GB, 64 GB eMMC, Gráficos Intel® UHD, W10, Plata',
            'almacen' => 3,
            'categoria' => 2,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Ratón Gaming - Logitech G502 Hero',
            'precio' => 53.19,
            'observaciones' => 'Puerto USB, Pesas opcionales, Respuesta 1000 Hz, Negro',
            'almacen' => 3,
            'categoria' => 3,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Ratón - Logitech M110',
            'precio' => 11.99,
            'observaciones' => '1000 DPI, USB, Óptico, Ambidestro, con cable, Gris',
            'almacen' => 3,
            'categoria' => 3,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Alfombrilla Gaming - Razer Goliathus Chroma',
            'precio' => 30.99,
            'observaciones' => 'RGB',
            'almacen' => 2,
            'categoria' => 4,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Alfombrilla gaming - SteelSeries QcK Mini',
            'precio' => 9.09,
            'observaciones' => 'goma, color negro',
            'almacen' => 1,
            'categoria' => 4,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Altavoces para PC - Creative Pebble',
            'precio' => 17.99,
            'observaciones' => '4.4 W, USB, 86 dB, Diseño Minimalista, Negro',
            'almacen' => 1,
            'categoria' => 5,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Altavoces para PC - Logitech Z213',
            'precio' => 47.99,
            'observaciones' => ' 2.1, Subwoofer, 7 W, Negro',
            'almacen' => 3,
            'categoria' => 5,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Monitor gaming - Acer NITRO VG270, 27"',
            'precio' => 199,
            'observaciones' => 'Full HD, IPS, 1ms, HDMI, VGA, Negro y rojo',
            'almacen' => 2,
            'categoria' => 6,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Monitor - LG UltraWide 29WN600-W, 29" WQHD',
            'precio' => 238,
            'observaciones' => '5 ms, 75 Hz, DisplayPort, HDMI, FreeSync, Plata',
            'almacen' => 3,
            'categoria' => 6,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Silla gaming - Drift DR 50 Pro',
            'precio' => 119,
            'observaciones' => 'Reposabrazos, Cojín cervical y lumbar, Reclinable, Giratorio, Negro y Azul',
            'almacen' => 1,
            'categoria' => 7,
        ]);
        DB::table('productos')->insert([
            'nombre' => 'Silla gaming - Corsair T3 RUSH',
            'precio' => 265.99,
            'observaciones' => '4D, Ergonómico, Altura regulable, Reposabrazos, 140 kg, Negro/Rojo',
            'almacen' => 1,
            'categoria' => 7,
        ]);
    }
}
